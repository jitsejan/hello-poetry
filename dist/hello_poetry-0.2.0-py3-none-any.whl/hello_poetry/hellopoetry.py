class HelloPoetry:

	def __init__(self):
		print("Hello Poetry")
