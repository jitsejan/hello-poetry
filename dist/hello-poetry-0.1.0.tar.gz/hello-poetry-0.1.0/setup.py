# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hello_poetry']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.25.1,<3.0.0']

setup_kwargs = {
    'name': 'hello-poetry',
    'version': '0.1.0',
    'description': 'A simple package to test a Poetry package',
    'long_description': '# Hello Poetry\n',
    'author': 'Jitse-Jan',
    'author_email': 'code@jitsejan.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/jitsejan/hello-poetry',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
